call Usr.Pipe_Services.Wait_Blue()
/
