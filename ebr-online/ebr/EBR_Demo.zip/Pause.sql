-- Choose between manual control or automatic, with time delay.

PAUSE

-- EXECUTE x.Sleep(2)
