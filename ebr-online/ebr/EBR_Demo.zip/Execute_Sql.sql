EXECUTE p(:Stmt)
EXECUTE execute immediate :Stmt
PROMPT
PROMPT *** Sql statement completed OK ***
