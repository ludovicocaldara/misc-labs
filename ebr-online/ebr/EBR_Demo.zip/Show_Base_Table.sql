select * from t_ order by PK
/
