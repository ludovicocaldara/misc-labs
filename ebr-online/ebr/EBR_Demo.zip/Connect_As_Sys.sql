CONNECT Sys/oracle@x/r12201 AS SYSDBA
alter session set Plsql_Warnings = 'Error:All'
/
