select PK, c from t order by PK
/
