CONNECT Usr/p@x/r12201
alter session set Plsql_Warnings = 'Error:All'
/
