/*
--Do this by hand:
@@Install_EBR_Readied_App
*/

CLEAR SCREEN
SPOOL Control.txt
WHENEVER SQLERROR EXIT

-- As Sys so's not to show up in the output from Show_Sessions_Per_Edition()
@@Connect_As_Sys

PROMPT Hit return to allow BLUE step 1
@@Pause
@@Continue_Blue

------------------------------------------------------------------------------------------

PROMPT Hit return to allow RED step 2
@@Pause
@@Continue_Red

PROMPT Hit return to allow BLUE step 3
@@Pause
@@Continue_Blue

PROMPT Hit return to allow GREEN step 4
@@Pause
@@Continue_Green

------------------------------------------------------------------------------------------

PROMPT Hit return to allow RED to step 5
@@Pause
@@Continue_Red

PROMPT Hit return to allow BLUE step 6
@@Pause
@@Continue_Blue

PROMPT Hit return to allow GREEN step 7
@@Pause
@@Continue_Green

------------------------------------------------------------------------------------------

PROMPT Hit return to allow RED to step 8
@@Pause
@@Continue_Red

PROMPT Hit return to allow BLUE step 9
@@Pause
@@Continue_Blue

PROMPT Hit return to allow GREEN step 10
@@Pause
@@Continue_Green

------------------------------------------------------------------------------------------

PROMPT Hit return to allow RED to step 11
@@Pause
@@Continue_Red

PROMPT Hit return to allow BLUE step 12
@@Pause
@@Continue_Blue

PROMPT Hit return to allow GREEN step 13
@@Pause
@@Continue_Green

------------------------------------------------------------------------------------------

PROMPT Hit return to allow RED to step 14
@@Pause
@@Continue_Red

PROMPT Hit return to allow BLUE step 15
@@Pause
@@Continue_Blue

PROMPT Hit return to allow GREEN step 16
@@Pause
@@Continue_Green

------------------------------------------------------------------------------------------

PROMPT Hit return to allow RED to step 17
@@Pause
@@Continue_Red

PROMPT Hit return to allow BLUE step 18
@@Pause
@@Continue_Blue

PROMPT Hit return to allow GREEN step 19
@@Pause
@@Continue_Green

------------------------------------------------------------------------------------------

PROMPT Hit return to allow RED to step 20
@@Pause
@@Continue_Red

PROMPT Hit return to allow BLUE step 21
@@Pause
@@Continue_Blue

PROMPT Hit return to allow GREEN step 22
@@Pause
@@Continue_Green

------------------------------------------------------------------------------------------

PROMPT Hit return to allow RED to step 23
@@Pause
@@Continue_Red

PROMPT Hit return to allow BLUE step 24
@@Pause
@@Continue_Blue

PROMPT Hit return to allow GREEN step 25
@@Pause
@@Continue_Green

------------------------------------------------------------------------------------------

PROMPT Hit return to allow RED to step 26
@@Pause
@@Continue_Red

PROMPT Hit return to allow BLUE step 27
@@Pause
@@Continue_Blue

PROMPT Hit return to allow GREEN step 28
@@Pause
@@Continue_Green

------------------------------------------------------------------------------------------

PROMPT Hit return to allow RED to step 29
@@Pause
@@Continue_Red

PROMPT Hit return to allow BLUE step 30
@@Pause
@@Continue_Blue

PROMPT Hit return to allow GREEN step 31
@@Pause
@@Continue_Green

------------------------------------------------------------------------------------------

PROMPT Hit return to allow RED to step 32
@@Pause
@@Continue_Red

PROMPT Hit return to allow BLUE step 33
@@Pause
@@Continue_Blue

PROMPT Hit return to allow GREEN step 34
@@Pause
@@Continue_Green

------------------------------------------------------------------------------------------

PROMPT Hit return to allow RED to step 35
@@Pause
@@Continue_Red

PROMPT Hit return to allow BLUE step 36
@@Pause
@@Continue_Blue

PROMPT Hit return to allow GREEN step 37
@@Pause
@@Continue_Green

------------------------------------------------------------------------------------------

PROMPT Hit return to allow RED to step 38
@@Pause
@@Continue_Red

PROMPT Hit return to allow BLUE step 39
@@Pause
@@Continue_Blue

PROMPT Hit return to allow GREEN step 40
@@Pause
@@Continue_Green

------------------------------------------------------------------------------------------

PROMPT Hit return to allow RED to step 41
@@Pause
@@Continue_Red

PROMPT Hit return to allow BLUE step 42
@@Pause
@@Continue_Blue

PROMPT
PROMPT
PROMPT ................................................................................
WHENEVER SQLERROR CONTINUE
PROMPT
PROMPT Done!
PROMPT
SPOOL OFF
